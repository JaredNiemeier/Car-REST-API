﻿using CarRESTAPI.Models;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Cors;

namespace CarRESTAPI.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    public class CarsController : ApiController
    {
        private Car[] cars = new Car[]
        {
            new Car("Honda", "Civic", 2006, "LICENSE1"),
            new Car("Chevy", "Bolt", 2011, "LICENSE2"),
            new Car("Audi", "RS 3", 2015, "LICENSE3"),
            new Car("Ford", "Expedition", 2019, "LICENSE4")
        };

        public IEnumerable<Car> GetAllCars()
        {
            return cars;
        }

    }
}
