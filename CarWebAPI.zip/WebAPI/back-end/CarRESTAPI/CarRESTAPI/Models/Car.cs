﻿using System;

namespace CarRESTAPI.Models
{
    public class Car
    {

        public String Make { get; set; }
        public String Model { get; set; }
        public int Year { get; set; }
        public String LicensePlateNumber { get; set; }

        public Car(String make, String model, int year, String licensePlateNumber)
        {
            this.Make = make;
            this.Model = model;
            this.Year = year;
            this.LicensePlateNumber = licensePlateNumber;
        }

    }
}