export class Car{

    Make: String;
    Model: String;
    Year: number;
    LicensePlateNumber: String;

}