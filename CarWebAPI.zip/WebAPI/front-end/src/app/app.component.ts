import { Component } from '@angular/core';
import { Car } from '../models/car';
import { CarService } from './services/car.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  private carList: Car[];
  public viewTable: boolean = false;

  constructor(private carService: CarService){

  }

  public getCars(){
    this.viewTable = true;
    this.carService.getCars()
    .then(response => {
      this.carList = response;
    })
  }

}
