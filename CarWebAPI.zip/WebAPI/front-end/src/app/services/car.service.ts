import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Car } from 'src/models/car';

@Injectable({
  providedIn: 'root'
})

export class CarService {

  constructor(private http: Http) { }

  getCars():Promise<Car[]>{
    return this.http.get("http://localhost:8000/api/cars").toPromise()
    .then(response => response.json() as Car[])
    .catch(error => Promise.reject(error.json || error))
    
  }

}
